
import numpy as np
from collections import Counter
from tqdm import tqdm
from matplotlib import pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix
import time

from utils.util import *
from models.transformerFPN_ub2 import TransAm_FPN, MyDataset
from models.cnn import CNNnet, MyDataset
from models.cnn_residual import Net_with_Res, MyDataset
from models.transformer1d_ub import TransAm, MyDataset
from models.atcnet import ATCNet
import os
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import argparse

parser = argparse.ArgumentParser(description='train and test lightning dataset')
parser.add_argument('--dataset', default='dataset/lightdataset_5types.pkl',type=str, help='Dataset of lightning pkl')
parser.add_argument('--batch_size', default=8, type=int, help='Batch size for dataloader')
parser.add_argument('--arch', default='TransAM_FPN', type=str, help='arch')
parser.add_argument('--gpus', default='2', type=str, help='CUDA_VISIBLE_DEVICES')
parser.add_argument('--window_size', default=1000, type=int, help='Window size for dataloader')
parser.add_argument('--lr', default=1e-4, type=float, help='learning rate')
parser.add_argument('--n_classes', default=10, type=int, help='lightning types')
parser.add_argument('--n_epoch', default=20, type=int, help='training epoch')
parser.add_argument('--save_logs',default='logs/TransAM_FPN/real_data/5/',type=str,help='Directory of save time,acc,f1 score')
parser.add_argument('--train_time',default='train_time.txt',type=str,help='train epoch time')
parser.add_argument('--accuracy',default='accuracy.txt',type=str,help='result accuracy')
parser.add_argument('--f1_score',default='f1_score.txt',type=str,help='f1 score')
parser.add_argument('--test_set',default=0.1,type=float,help='the proportion of the dataset to include in the test split')
parser.add_argument('--type',default='10types',type=str,help='10types or 5types')

args = parser.parse_args()

if __name__ == "__main__":

    X_train, X_test, Y_train, Y_test, pid_test = read_data_physionet_4(dataset=args.dataset,window_size=args.window_size,test_set=args.test_set)
    X_train = X_train[0:args.batch_size*(X_train.shape[0]//args.batch_size)]
    X_test = X_test[0:args.batch_size * (X_test.shape[0] // args.batch_size)]
    Y_train = Y_train[0:args.batch_size * (Y_train.shape[0] // args.batch_size)]
    Y_test = Y_test[0:args.batch_size * (Y_test.shape[0] // args.batch_size)]
    pid_test = []
    for i in range(X_test.shape[0]):
        pid_test.append(i)

    dataset = MyDataset(X_train, Y_train)
    dataset_test = MyDataset(X_test, Y_test)
    dataloader = DataLoader(dataset, batch_size=args.batch_size)
    dataloader_test = DataLoader(dataset_test, batch_size=args.batch_size, drop_last=False)

    # make model
    device = torch.device('cuda:'+args.gpus if torch.cuda.is_available() else 'cpu')
    if (args.arch == 'CNNnet'):
        model = CNNnet()
    elif (args.arch == 'Net_with_Res'):
        model = Net_with_Res()
    elif (args.arch == 'TransAM'):
        model = TransAm(feature_size=args.window_size, num_classes=10, num_layers=6, dropout=0.1)
    elif (args.arch == 'TransAM_FPN'):
        model = TransAm_FPN(n_classes=5,
                            n_length=args.window_size,
                            d_model=64,
                            nhead=2,
                            dim_feedforward=512,
                            dropout=0.4,
                            activation='softmax')
    elif (args.arch == 'atcnet'):
        model = ATCNet(1,5)
    model.to(device)

    # train and test
    model.verbose = False
    optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=0)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=10)
    loss_func = torch.nn.CrossEntropyLoss()

    step = 0
    f1_ls = []
    start = time.time()
    train_time = []
    accuracy = []
    f1_score = []
    score = []

    for per_epoch in tqdm(range(args.n_epoch), desc="epoch", leave=False):

        # train
        model.train()
        prog_iter = tqdm(dataloader, desc="Training", leave=False)
        for batch_idx, batch in enumerate(prog_iter):
            optimizer.zero_grad()
            input_x, input_y = tuple(t.to(device) for t in batch)
            input_y = input_y.float()
            pred = model(input_x)
            loss = loss_func(pred, input_y)

            loss.backward()
            # Apply gradient clipping
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            step += 1

        scheduler.step(per_epoch)
        end = time.time()
        train_time_per = end - start

        # test
        model.eval()
        prog_iter_test = tqdm(dataloader_test, desc="Testing", leave=False)
        all_pred_prob = []
        for batch_idx, batch in enumerate(prog_iter_test):
            input_x, input_y = tuple(t.to(device) for t in batch)
            pred = model(input_x)
            all_pred_prob.append(pred.cpu().data.numpy())

        all_pred_prob = np.concatenate(all_pred_prob)

        final_pred = []
        final_gt = []
        for i_pid in np.unique(pid_test):
            sample_indices = np.where(pid_test == i_pid)[0]
            sample_predictions = all_pred_prob[sample_indices]
            final_pred.append(np.argmax(np.mean(sample_predictions, axis=0)))  # Majority voting per patient
            final_gt.append(np.argmax(Y_test[sample_indices][0]))  # Take the ground truth from the first sample of each patient

        ## classification report
        tmp_report = classification_report(final_gt, final_pred, output_dict=True)
        #       print(confusion_matrix(final_gt, final_pred))
        print("accuracy:", tmp_report['accuracy'])
        print("F1 score:", tmp_report['weighted avg']['f1-score'])
        # print(classification_report(final_gt, final_pred,target_names=['-CG','CG-IR', 'NBE', '+CG','CC', '+PBP','-PBP', '-NBE', '+NBE', 'sky wave']))
        print(classification_report(final_gt, final_pred,target_names=['-CC','CG', 'MP', '+NBE','OTHER']))


        f1_ls.append(tmp_report['weighted avg']['f1-score'])

        train_time.append(train_time_per)
        # np.save(args.save_logs +'score'+ r'{}.npy'.format(per_epoch),tmp_report)

        accuracy.append(tmp_report['accuracy'])
        f1_score.append(tmp_report['macro avg']['f1-score'])

        # per_score = [tmp_report['0']['f1-score'], tmp_report['1']['f1-score'], tmp_report['2']['f1-score'], tmp_report['3']['f1-score'], tmp_report['4']['f1-score'],
        #      tmp_report['5']['f1-score'], tmp_report['6']['f1-score'], tmp_report['7']['f1-score'], tmp_report['8']['f1-score'], tmp_report['9']['f1-score'],
        #      tmp_report['accuracy'], tmp_report['macro avg']['f1-score'], tmp_report['weighted avg']['f1-score']]
        per_score = [tmp_report['0']['f1-score'], tmp_report['1']['f1-score'], tmp_report['2']['f1-score'],
                     tmp_report['3']['f1-score'], tmp_report['4']['f1-score'],
                     tmp_report['accuracy'], tmp_report['macro avg']['f1-score'],
                     tmp_report['weighted avg']['f1-score']]

        ROC = {'gt': Y_test, 'pred': all_pred_prob, 'order': final_gt}
        # np.save(args.save_logs +'ROC'+ r'{}.npy'.format(per_epoch), ROC)

        # print(accuracy)
        #
        # print(f1_ls)
        # np.savetxt(args.save_logs + args.train_time, train_time, fmt='%.2e')
        # np.savetxt(args.save_logs + args.accuracy, accuracy, fmt='%.2e')
        # np.savetxt(args.save_logs + args.f1_score, f1_score, fmt='%.2e')
    # f1_average = sum(f1_ls)/n_epoch
    # print("F1 average score:", f1_average)

    # np.savetxt(args.save_logs+args.train_time,train_time,fmt='%.2e')
    # np.savetxt(args.save_logs+args.accuracy,accuracy,fmt='%.2e')
    # np.savetxt(args.save_logs+args.f1_score,f1_score,fmt='%.2e')

    # score.append(per_score)

    # np.save(args.save_logs + 'score.npy', per_score)










