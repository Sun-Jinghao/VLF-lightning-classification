import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
import torch.nn as nn
import torch
import argparse
from matplotlib import rcParams

parser = argparse.ArgumentParser(description='generate ROC curves')
parser.add_argument('--input_dir',default='logs/CNN_Residual/',type=str,help='directory of ROC.npy')
parser.add_argument('--out_dir',default='results/ROC_curves/CNN_Residual/',type=str,help='directory of results image')
args = parser.parse_args()

def ROC_curve(y_test,y_prob,col):
    # 计算ROC曲线
    fpr, tpr, thresholds = roc_curve(y_test, y_prob)
    roc_auc = auc(fpr, tpr)

    # 绘制ROC曲线
    plt.figure()
    lw = 2
    plt.plot(fpr, tpr, color='darkorange',
             lw=lw, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot(fpr, tpr, color='green',
             lw=lw, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    # plt.title('  ')
    plt.legend(loc="lower right")

    plt.gcf().set_size_inches(20, 12)  # 获取当前图像

    # plt.savefig(r'{}.png'.format(col),dpi=300)
    plt.savefig(args.out_dir+r'{}.png'.format(col),dpi=600)

    plt.show()

def Tmp(roc,num):
    ROC = roc.tolist()
    gt = ROC['gt']
    pred = ROC['pred']
    order = np.array(ROC['order'])

    per_order = np.where(order == num)
    per_gt = gt[per_order]
    per_pred = pred[per_order]

    y_test = per_gt.flatten()
    y_prob = per_pred.flatten()

    return y_test,y_prob

        # ROC_curve(y_test, y_prob, i)
    # ROC_curve(y_test, y_prob, i)


if __name__ == '__main__':
    # 准备样本标签和预测概率
    # ROC = np.load('logs/TransAM_FPN/ROC.npy', allow_pickle=True)
    cnn1 = np.load('ROC/CNN/ROC.npy',allow_pickle=True)
    cnn_res1 = np.load('ROC/CNN_Residual/ROC.npy',allow_pickle=True)
    transAm1 = np.load('ROC/TransAM/ROC11.npy',allow_pickle=True)
    transAmFPN1 = np.load('ROC/TransAM_FPN/ROC11.npy',allow_pickle=True)

    cnn_test1, cnn_prob1 = Tmp(cnn1, 1)
    cnn_res_test1, cnn_res_prob1 = Tmp(cnn_res1, 1)
    transAM_test1, transAM_prob1 = Tmp(transAm1, 1)
    transAM_FPN_test1, transAM_FPN_prob1 = Tmp(transAmFPN1, 1)

    fpr1, tpr1, thresholds = roc_curve(cnn_test1, cnn_prob1)
    fpr2, tpr2, thresholds = roc_curve(cnn_res_test1, cnn_res_prob1)
    fpr3, tpr3, thresholds = roc_curve(transAM_test1, transAM_prob1)
    fpr4, tpr4, thresholds = roc_curve(transAM_FPN_test1, transAM_FPN_prob1)
    roc_auc1 = auc(fpr1, tpr1)
    roc_auc2 = auc(fpr2, tpr2)
    roc_auc3 = auc(fpr3, tpr3)
    roc_auc4 = auc(fpr4, tpr4)

    # 绘制ROC曲线
    plt.figure()
    from matplotlib import rcParams

    config = {
        # "font.family": 'Times New Roman',  # 设置字体类型
        "font.size": 30,
        #     "mathtext.fontset":'stix',
    }
    rcParams.update(config)
    lw = 4
    plt.plot(fpr1, tpr1, color='darkorange',
             lw=lw, label='CNN ROC curve (area = %0.2f)' % roc_auc1)
    plt.plot(fpr2, tpr2, color='green',
             lw=lw, label='CNN_Residual ROC curve (area = %0.2f)' % roc_auc2)
    plt.plot(fpr3, tpr3, color='red',
             lw=lw, label='Transformer ROC curve (area = %0.2f)' % roc_auc3)
    plt.plot(fpr4, tpr4, color='black',
             lw=lw, label='Ours ROC curve (area = %0.2f)' % roc_auc4)
    plt.plot([0.0001, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    # x = xrange(0,1,0.2)

    # [None, 0.2, 0.4, 0.6, 0.8, 1.0],

    plt.xticks(fontsize=40)
    plt.yticks(fontsize=40)


    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    # plt.xlabel('False Positive Rate')
    # plt.ylabel('True Positive Rate')
    # plt.title('  ')
    plt.legend(loc="lower right")

    plt.gcf().set_size_inches(20, 12)  # 获取当前图像

    # plt.savefig(r'{}.png'.format(col),dpi=300)
    plt.savefig(args.out_dir + r'{}.png'.format(11), dpi=600)

    plt.show()




    # ROC = np.load(args.input_dir + 'ROC.npy',allow_pickle=True)
    # ROC = ROC.tolist()
    #
    # gt = ROC['gt']
    # pred = ROC['pred']
    # order = np.array(ROC['order'])
    #
    # for i in range(10):
    #     if (i == 1) or (i == 7):
    #         per_order = np.where(order == i)
    #         per_gt = gt[per_order]
    #         per_pred = pred[per_order]
    #
    #         y_test = per_gt.flatten()
    #         y_prob = per_pred.flatten()
    #         ROC_curve(y_test, y_prob, i)

