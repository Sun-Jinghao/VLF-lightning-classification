import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torch
import torch.autograd as autograd

class MyDataset(Dataset):
    def __init__(self, data, label):
        self.data = data
        self.label = label

    def __getitem__(self, index):
        return (torch.tensor(self.data[index], dtype=torch.float), torch.tensor(self.label[index], dtype=torch.long))

    def __len__(self):
        return len(self.data)


class MyConv1dPadSame(nn.Module):
    """
    extend nn.Conv1d to support SAME padding
    """
    def __init__(self, in_channels, out_channels, kernel_size, stride, groups=1):
        super(MyConv1dPadSame, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.groups = groups
        self.conv = torch.nn.Conv1d(
            in_channels=self.in_channels,
            out_channels=self.out_channels,
            kernel_size=self.kernel_size,
            stride=self.stride,
            groups=self.groups)

    def forward(self, x):
        net = x

        # compute pad shape
        in_dim = net.shape[-1]
        out_dim = (in_dim + self.stride - 1) // self.stride
        p = max(0, (out_dim - 1) * self.stride + self.kernel_size - in_dim)
        pad_left = p // 2
        pad_right = p - pad_left
        net = F.pad(net, (pad_left, pad_right), "constant", 0)

        net = self.conv(net)

        return net

class TransAm_FPN(nn.Module):
    def __init__(self, n_classes, n_length, d_model, nhead, dim_feedforward, dropout, activation, num_layers=6, verbose=False):
        super(TransAm_FPN, self).__init__()

        self.n_classes = n_classes
        self.n_length = n_length
        self.d_model = d_model
        self.nhead = nhead
        self.dim_feedforward = dim_feedforward
        self.dropout = dropout
        self.activation = activation
        self.num_layers = num_layers
        self.verbose = verbose

        # FPN-like layers for 1D data
        # self.fpn_conv1 = MyConv1dPadSame(in_channels=1, out_channels=d_model, kernel_size=3, stride=2)
        self.fpn_conv1 = nn.Sequential(
            MyConv1dPadSame(in_channels=1, out_channels=d_model, kernel_size=3, stride=2),
            nn.BatchNorm1d(d_model),
        )
        self.fpn_conv2 = nn.Sequential(
            MyConv1dPadSame(in_channels=d_model,out_channels=d_model,kernel_size=3,stride=2),
            nn.BatchNorm1d(d_model),
        )
        self.fpn_conv3 = nn.Sequential(
            MyConv1dPadSame(in_channels=d_model, out_channels=d_model, kernel_size=3, stride=2),
            nn.BatchNorm1d(d_model),
        )
        self.fpn_conv4 = nn.Sequential(
            MyConv1dPadSame(in_channels=d_model, out_channels=d_model, kernel_size=3, stride=2),
            nn.BatchNorm1d(d_model),
        )


        # self.fpn_conv2 = MyConv1dPadSame(in_channels=d_model, out_channels=d_model, kernel_size=3, stride=2)
        # self.fpn_conv3 = MyConv1dPadSame(in_channels=d_model, out_channels=d_model, kernel_size=3, stride=2)
        # self.fpn_conv4 = MyConv1dPadSame(in_channels=d_model, out_channels=d_model, kernel_size=3, stride=2)

        self.fpn_upsample = nn.Upsample(scale_factor=2, mode='nearest')

        self.fpn_p3_conv1 = nn.Conv1d(in_channels=d_model, out_channels=d_model, kernel_size=1)
        self.fpn_p3_conv2 = nn.Conv1d(in_channels=d_model, out_channels=d_model, kernel_size=3, padding=1)

        self.fpn_p4_conv1 = nn.Conv1d(in_channels=d_model, out_channels=d_model, kernel_size=1)
        self.fpn_p4_conv2 = nn.Conv1d(in_channels=d_model, out_channels=d_model, kernel_size=3, padding=1)

        self.fpn_p5_conv1 = nn.Conv1d(in_channels=d_model, out_channels=d_model, kernel_size=1)
        self.fpn_p5_conv2 = nn.Conv1d(in_channels=d_model, out_channels=d_model, kernel_size=3, padding=1)
        # Add residual connections after FPN-like layers and Transformer Encoder
        self.residual_conv = nn.Conv1d(d_model,d_model, kernel_size=1)
        self.residual_norm = nn.LayerNorm(d_model)

        self.full_layer = nn.Sequential(
            nn.Linear(in_features=4096, out_features=1024),
            nn.BatchNorm1d(1024),
            # nn.ReLU(),
            # nn.MaxPool1d(2,2),
            nn.Linear(in_features=1024, out_features=256),
            nn.BatchNorm1d(256),
            # nn.ReLU(),
            # nn.MaxPool1d(2,2),
            nn.Linear(in_features=256, out_features=64),
            nn.BatchNorm1d(64),
            # nn.ReLU(),
            nn.Linear(in_features=64,out_features=5),
        )

        self.softmax= nn.Softmax(dim=1)


        # Calculate the final size of FPN output after the last FPN-like layer
        final_transformer_output_size = d_model * 63  # the length of out.size(2)

        # Transformer Encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout)

        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        # Layer normalization
        self.layer_norm = nn.LayerNorm(d_model)

        # Output layer
        self.dense = nn.Linear(d_model, n_classes)

        self.verbose = verbose

    def forward(self, x):
        out = x
        if self.verbose:
            print('input (n_samples, n_channel, n_length)', out.shape)

        # FPN-like operations
        p3 = self.fpn_conv1(out)
        p4 = self.fpn_conv2(p3)
        p5 = self.fpn_conv3(p4)
        p6 = self.fpn_conv4(p5)

        p5_upsampled = self.fpn_upsample(p6)[:,:,: 125] + p5
        p4_upsampled = self.fpn_upsample(p5_upsampled) + p4
        p3_upsampled = self.fpn_upsample(p4_upsampled) + p3

        p3_out = self.fpn_p3_conv1(p3_upsampled)
        p3_out = self.fpn_p3_conv2(p3_out)
        net = torch.nn.MaxPool1d(4)
        p3_out1 = net(p3_out)

        p4_out = self.fpn_p4_conv1(p4_upsampled)
        p4_out = self.fpn_p4_conv2(p4_out)
        net = torch.nn.MaxPool1d(2)
        p4_out1 = net(p4_out)

        p5_out = self.fpn_p5_conv1(p5_upsampled)
        p5_out = self.fpn_p5_conv2(p5_out)

        out = p3_out1 + p4_out1 + p5_out

        pooling_layer = nn.MaxPool1d(2)
        out = pooling_layer(out)
        out = F.pad(out, (0, 2))
        # Add residual connections
        out = out + self.residual_norm(self.residual_conv(out))

        # Transformer Encoder
        out = self.transformer_encoder(out)
        if self.verbose:
            print('transformer_encoder', out.shape)

        # out = self.layer_norm(out)
        B,H,W = out.shape
        out = out.view(B,H*W)
        out = self.full_layer(out)
        out = self.softmax(out)

        # Layer normalization
        # out = self.layer_norm(out)

        # Global average pooling
        # out = torch.mean(out, dim=1)

        # out = self.dense(out)

        return out

"""
# Create an instance of the model
model = TransAm(n_classes=5, n_length=1280, d_model=64, nhead=2, dim_feedforward=256, dropout=0.1, activation='relu')

# Set the model to evaluation mode
model.eval()

# Generate sample input data
batch_size = 2
input_length = 1280
input_data = torch.randn(batch_size, 1, input_length, requires_grad=True)  # Enable gradients

# Forward pass
output = model(input_data)

# Compute gradients
grads = autograd.grad(outputs=output, inputs=input_data, grad_outputs=torch.ones_like(output), create_graph=True)
print(grads)
# Print and compare gradients








if __name__ == "__main__":
    rgb = torch.randn(100, 1, 1000)
    net = TransAm(n_classes=10, n_length=1000, d_model=64, nhead=2, dim_feedforward=512, dropout=0.1,activation='softmax')
    out = net(rgb)
    print(out.shape)
"""
