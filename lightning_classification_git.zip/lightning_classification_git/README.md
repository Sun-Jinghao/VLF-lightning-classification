2023_9_6:
这个版本是可以用的，留作备份，日后，只留一份备份

创建数据集：create_data.py
训练和测试代码：test.py
运行方法：sh script/train_cnn.sh