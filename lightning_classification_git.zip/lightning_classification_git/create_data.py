from glob import glob
from tqdm import tqdm
import numpy as np
import os
import cv2
import pickle
import multiprocessing
import argparse

parser = argparse.ArgumentParser(description='Generate pickle data from lightning_dataset')
parser.add_argument('--src_dir', default='dataset/lightning_dataset_5types', type=str, help='Directory for common lightning datset')
parser.add_argument('--tar_dir', default='dataset/lightdataset_5types.pkl',type=str, help='Directory for pickel data')
parser.add_argument('--types',default='5types',type=str,help='datasets type: 5types & 10types')

args = parser.parse_args()

src = args.src_dir
tar = args.tar_dir

dict_light_10types = {'01.npy':['-CG',1321],'02.npy':['CG-IR',1852],'03.npy':['NBE',1180],
              '04.npy':['+CG',179],'05.npy':['CC',260],'06.npy':['+PBP',417],
              '07.npy':['-PBP',830],'08.npy':['-NBE',729],'09.npy':['+NBE',298],
              '010.npy':['sky wave',2345],}
dict_light_5types = {'cc.npy':['-CC',373],'cg.npy':['CG',126],'multiply.npy':['MULTIPLY',74],
              'nbe.npy':['NBE',93],'other.npy':['OTHER',29],}

if(args.types == '10types'):
    dict_light = dict_light_10types
elif(args.types == '5types'):
    dict_light = dict_light_5types

filenames = os.path.join(src)

data_list = []
label_list = []
all_data = []
all_label = []
data = []
for filename in os.listdir(filenames):
    print(filename)
    path = filenames+'/'+filename
    data = np.load(path)
    label_name = dict_light[filename][0]
    label_num = dict_light[filename][1]
    label = [label_name]*label_num
    data_list.append(data)
    label_list.append(label)

for i in data_list:
    for j in i:
        all_data.append(j)

for i in label_list:
    for j in i:
        all_label.append(j)

all_data = np.array(all_data)
all_label = np.array(all_label)

res = {'data':all_data,'label':all_label}

with open(tar,'wb') as fout:
    pickle.dump(res, fout)
print(res)