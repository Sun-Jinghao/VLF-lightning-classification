# Transformer_FPN epoch=20,lr=1e-4,save:logs/TransAM_FPN
python3 ./test.py --arch TransAM_FPN --gpus 2 --test_set 0.1   --n_epoch 12 --lr 1e-4 --save_logs 'logs/TransAM_FPN/5/'