import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
import torch.nn as nn
import pandas as pd
import os

if __name__ == '__main__':
    a1 = 'logs/TransAM_FPN/1/score.npy'
    a2 = 'logs/TransAM_FPN/2/score.npy'
    a3 = 'logs/TransAM_FPN/3/score.npy'
    a4 = 'logs/TransAM_FPN/4/score.npy'
    a5 = 'logs/TransAM_FPN/5/score.npy'

    b1 = np.load(a1,allow_pickle=True)
    b2 = np.load(a2,allow_pickle=True)
    b3 = np.load(a3,allow_pickle=True)
    b4 = np.load(a4,allow_pickle=True)
    b5 = np.load(a5,allow_pickle=True)

    # b1 = int(b1)
    b1 = np.around(b1*100, 0)
    b2 = np.around(b2*100, 0)
    b3 = np.around(b3*100, 0)
    b4 = np.around(b4*100, 0)
    b5 = np.around(b5*100, 0)

    b1.tolist()
    b2.tolist()
    b3.tolist()
    b4.tolist()
    b5.tolist()

    dd = [b1,b2,b3,b4,b5]

    dd = np.array(dd)
    dd.transpose()
    # print(dd)
    df = pd.DataFrame(dd)
    writer = pd.ExcelWriter('5score.xlsx')
    df.to_excel(writer, sheet_name='Sheet1')
    writer.save()





