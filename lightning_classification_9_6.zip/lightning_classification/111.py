import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
import torch.nn as nn
import pandas as pd
import os
import torch
from models.atcnet import ATCNet


all = []

if __name__ == '__main__':
    a = torch.randn([10, 1, 1000])
    model = ATCNet(1, 10)
    b = model(a)
    print(b.shape)



















    # file = 'logs/TransAM/1'
    # for i in range(15):
    #     print(i)
    #     path = file + '/' + 'score' + str(i) + '.npy'
    #     a = np.load(path,allow_pickle=True)
    #     a = a.tolist()
    #     b = [a['0']['f1-score'], a['1']['f1-score'], a['2']['f1-score'], a['3']['f1-score'], a['4']['f1-score'],
    #          a['5']['f1-score'], a['6']['f1-score'], a['7']['f1-score'], a['8']['f1-score'], a['9']['f1-score'],
    #          a['accuracy'], a['macro avg']['f1-score'], a['weighted avg']['f1-score']]
    #     c = np.array(b)
    #     c = np.around(b, 2)
    #     all.append(c)
    #
    # # print(all)
    # all = np.array(all)
    # all = all.transpose()
    # df = pd.DataFrame(all)
    #
    # writer = pd.ExcelWriter(file+ '/'+ 'score.xlsx')
    # df.to_excel(writer, sheet_name='Sheet1')
    # writer.save()

    # a = np.load('logs/TransAM_FPN/score1.npy',allow_pickle=True)
    # a = a.tolist()
    # b = [a['0']['f1-score'],a['1']['f1-score'],a['2']['f1-score'],a['3']['f1-score'],a['4']['f1-score'],a['5']['f1-score'],a['6']['f1-score'],a['7']['f1-score'],a['8']['f1-score'],a['9']['f1-score'],a['accuracy'],a['macro avg']['f1-score'],a['weighted avg']['f1-score']]
    # c = np.array(b)
    # c = np.around(b,2)
    # # np.savetxt('0.txt'.format(2),c)
    # df = pd.DataFrame(c)
    #
    # writer = pd.ExcelWriter('11.xlsx')
    # df.to_excel(writer, sheet_name='Sheet1')
    # writer.save()

