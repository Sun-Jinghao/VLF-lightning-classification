#python3 ./train/train_denoise.py --arch Uformer_B --batch_size 32 --gpu '0,1' \
#    --train_ps 128 --train_dir ../datasets/denoising/sidd/train --env _0706 \
#    --val_dir ../datasets/denoising/sidd/val --save_dir ./logs/ \
#    --dataset sidd --warmup


# CNN epoch=40,lr=0.01,save:logs/CNN
python3 ./test.py --arch CNNnet --gpus 0 --n_epoch 15 --lr 1e-4 --save_logs 'logs/CNN/'