# Transformer1D epoch=20,lr=1e-4,save:logs/TransAM
python3 ./test.py --arch TransAM --gpus 3 --n_epoch 15 --lr 1e-4 --save_logs 'logs/TransAM/'