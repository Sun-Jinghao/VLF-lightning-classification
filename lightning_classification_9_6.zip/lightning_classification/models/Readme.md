模型：
CNN；
CNN_residual;
Transformer;
Ours(Transformer+FPN);
