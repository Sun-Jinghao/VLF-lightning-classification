import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader


class MyDataset(Dataset):
    def __init__(self, data, label):
        self.data = data
        self.label = label

    def __getitem__(self, index):
        return (torch.tensor(self.data[index], dtype=torch.float), torch.tensor(self.label[index], dtype=torch.long))

    def __len__(self):
        return len(self.data)

class TransAm(nn.Module):
    def __init__(self, feature_size, num_classes, num_layers, dropout):
        super(TransAm, self).__init__()
        self.model_type = 'Transformer'

#        self.src_mask = None
        self.encoder_layer = nn.TransformerEncoderLayer(d_model=feature_size, nhead=2, dropout=dropout)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=num_layers)
        self.decoder = nn.Linear(feature_size, num_classes)  # Change output dimension
#        self.init_weights()

        self.feature_size = feature_size
        self.num_layers = num_layers
        self.dropout = dropout

        self.softmax = nn.Softmax(dim=1)

    def feature(self):
        return {"feature_size": self.feature_size, "num_layers": self.num_layers, "dropout": self.dropout}


    def forward(self,x):
        output = x

        output = self.transformer_encoder(output)
        output = output.view(output.shape[0], -1)
        output = self.decoder(output)
        return output

    def _generate_square_subsequent_mask(self, sz):
        mask = (torch.triu(torch.ones(sz, sz)) == 1).transpose(0, 1)
        mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
        return mask
"""
if __name__ == "__main__":
    rgb = torch.randn(100, 1, 1280)
    window_size = 1280
    net = TransAm(feature_size=window_size, num_classes=5, num_layers=1, dropout=0.1)  # Specify the number of classes
    out = net(rgb)
    print(out.shape)
 if self.src_mask is None or self.src_mask.size(0) != len(src):
            device = src.device
            mask = self._generate_square_subsequent_mask(len(src)).to(device)
            self.src_mask = mask
    def init_weights(self):
        initrange = 0.1
        self.decoder.bias.data.zero_()
        self.decoder.weight.data.uniform_(-initrange, initrange)


"""









