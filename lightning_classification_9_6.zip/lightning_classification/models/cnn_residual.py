import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

class MyDataset(Dataset):
    def __init__(self, data, label):
        self.data = data
        self.label = label

    def __getitem__(self, index):
        return (torch.tensor(self.data[index], dtype=torch.float), torch.tensor(self.label[index], dtype=torch.long))

    def __len__(self):
        return len(self.data)

class ResNet_basic_block(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(ResNet_basic_block, self).__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.BN1 = nn.BatchNorm1d(num_features=out_channels)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.BN2 = nn.BatchNorm1d(num_features=out_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.BN1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.BN2(out)
        out += residual
        out = self.relu(out)
        return out


class Net_with_Res(nn.Module):
    def __init__(self):
        super(Net_with_Res, self).__init__()

        self.conv1 = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Conv1d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
        )
        self.pool1 = nn.MaxPool1d(kernel_size=2, stride=2)

        self.conv2 = nn.Sequential(
            ResNet_basic_block(in_channels=64, out_channels=64),
            nn.Conv1d(in_channels=64, out_channels=96, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(96),
            nn.ReLU(),
            nn.Conv1d(in_channels=96, out_channels=128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
        )
        self.pool2 = nn.MaxPool1d(kernel_size=2, stride=2)

        self.conv3 = nn.Sequential(
            ResNet_basic_block(in_channels=128, out_channels=128),
            nn.Conv1d(in_channels=128, out_channels=192, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(192),
            nn.ReLU(),
            nn.Conv1d(in_channels=192, out_channels=256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(256),
            nn.ReLU(),
        )
        self.pool3 = nn.MaxPool1d(kernel_size=2, stride=2)

        self.conv4 = nn.Sequential(
            ResNet_basic_block(in_channels=256, out_channels=256),
            nn.Conv1d(in_channels=256, out_channels=384, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(384),
            nn.ReLU(),
            nn.Conv1d(in_channels=384, out_channels=512, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(512),
            nn.ReLU(),
        )
        self.pool4 = nn.MaxPool1d(kernel_size=2, stride=2)

        self.conv5 = nn.Sequential(
            ResNet_basic_block(in_channels=512, out_channels=512),
            nn.Conv1d(in_channels=512, out_channels=768, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(768),
            nn.ReLU(),
            nn.Conv1d(in_channels=768, out_channels=1024, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(1024),
            nn.ReLU(),
        )
        self.pool5 = nn.MaxPool1d(kernel_size=2, stride=2)
        self.pool6 = nn.MaxPool1d(kernel_size=2, stride=2)

        self.global_pool = nn.AdaptiveAvgPool1d(1)  # 全局平均池化层

        self.num = 1

        self.full_layer = nn.Sequential(
            nn.Linear(in_features=1024 * self.num, out_features=512 * self.num),
            nn.ReLU(),
            nn.Linear(in_features=512 * self.num, out_features=256 * self.num),
            nn.ReLU(),
            nn.Linear(in_features=256 * self.num, out_features=128 * self.num),
            nn.ReLU(),
            nn.Linear(in_features=128 * self.num, out_features=64 * self.num),
            nn.ReLU(),
            nn.Linear(in_features=64 * self.num, out_features=16 * self.num),
            nn.ReLU(),
            nn.Linear(in_features=16 * self.num, out_features=10),
        )

        self.fc = nn.Linear(in_features=1024, out_features=10)  # 将输出特征数改为10
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x): #10,1,1000   1024 ->256 ->128->64->32->16
        x = self.conv1(x)
        x = self.pool1(x)
        x = self.conv2(x)
        x = self.pool2(x)
        x = self.conv3(x)
        x = self.pool3(x)
        x = self.conv4(x)
        x = self.pool4(x)
        x = self.conv5(x)
        x = self.pool5(x)
        x = self.pool6(x)
        x = self.pool6(x)

        x = self.global_pool(x)  # 全局平均池化

        x = x.view(x.size(0), -1)

        x = self.full_layer(x)
        # x = self.fc(x)
        x = self.softmax(x)

        return x
"""
if __name__ == "__main__":
    # 创建模型实例
    model = Net_with_Res()
    # 创建输入数据
    x = torch.randn(10, 1, 1000)  # 输入数据形状：64个样本，1个通道，1000个长度
    # 进行前向传播
    y = model(x)
    # 输出预测结果的形状
    print(y.shape)



"""





