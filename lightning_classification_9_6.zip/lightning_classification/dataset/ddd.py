import pickle
import os
import numpy as np
import matplotlib.pyplot as plt

dataset = 'lightning_dataset_5types/other.npy'
# dataset = 'cg_old.npy'

data = np.load(dataset,allow_pickle=True)

# for i in range(10):
#     gauss = 10 * np.random.normal(mu, sigma, data.shape[1])


#
#噪声
# 高斯
gauss_data1 = []
gauss_data2 = []

mu, sigma = 0, 1 # 正态分布的均值和标准差
gauss = 10 * np.random.normal(mu, sigma, data.shape[1]) # 生成与数据长度相同的正态分布随机数

# labulasi
laps_data1 = []
laps_data2 = []

scale = 1.0 # 噪声的尺度参数
laps = 10 * np.random.laplace(0, scale, data.shape[1]) # 生成与数据长度相同的拉普拉斯随机数

#混合噪声
mix_data1 = []
mix_data2 = []
from scipy.stats import rayleigh# 创建一个10x10的矩阵
rayli = 10 * rayleigh.rvs(loc=0, scale=1, size=data.shape[1]).reshape(1,data.shape[1])# 将瑞利噪声加入到数据中


for i in range(data.shape[0]):
    noisy_gauss1 = data[i,:] + 10 * np.random.normal(mu, sigma, data.shape[1])
    noisy_gauss2 = data[i, :] + 20 * np.random.normal(mu, sigma, data.shape[1])
    noisy_laps1 = data[i,:] + 10 * np.random.laplace(0, scale, data.shape[1])
    noisy_laps2 = data[i, :] + 20 * np.random.laplace(0, scale, data.shape[1])
    noisy_mix1 = data[i,:] + 5 * np.random.normal(mu, sigma, data.shape[1]) + 5 * np.random.laplace(0, scale, data.shape[1])
    noisy_mix2 = data[i,:] + 10 * np.random.normal(mu, sigma, data.shape[1]) + 10 * np.random.laplace(0, scale, data.shape[1])


    gauss_data1.append(noisy_gauss1)
    gauss_data2.append(noisy_gauss2)
    laps_data1.append(noisy_laps1)
    laps_data2.append(noisy_laps2)
    mix_data1.append(noisy_mix1)
    mix_data2.append(noisy_mix2)

# print(data[0,0:20])
# # print(gauss_data[0,0:20])
# # plt.figure()
# #
# # plt.plot(data[0,300:400],label = 'gt')
# # # plt.plot(gauss_data[0][300:400],label = 'gas')
# # # plt.plot(laps_data[0][300:400],label = 'laps')
# # plt.plot(mix_data[0][300:400],label = 'ray')
# # # plt.legend(loc="lower right")
# #
# #
# # plt.show()
#
gauss_data1 = np.array(gauss_data1)
gauss_data2 = np.array(gauss_data2)
laps_data1 = np.array(laps_data1)
laps_data2 = np.array(laps_data2)
mix_data1 = np.array(mix_data1)
mix_data2 = np.array(mix_data2)

all_data = np.vstack((data,gauss_data1,laps_data1,mix_data1,gauss_data2,laps_data2,mix_data2))

# all_data = np.vstack((data,gauss_data1,laps_data1,gauss_data2))


print(all_data.shape)
np.save('lightning_dataset_5types/other.npy',all_data)



