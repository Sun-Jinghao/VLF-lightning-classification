lightning_dataset_10types:10类公共数据集
lightning_dataset_5types：我们自己的数据集，共5类。
