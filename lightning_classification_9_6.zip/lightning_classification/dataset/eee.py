import matplotlib.pyplot as plt
import numpy as np

data = np.load('lightning_dataset_5types/cg.npy')



plt.figure()
plt.plot(data[8])
plt.savefig('+CG.png',dpi=600)
plt.show()